import os
import sys
import threading
import time
import uvicorn

def run_fastapi():
    print("[+] Starting FastAPI License & Validation Server on port 8000...")
    # Run panel and validation API
    uvicorn.run("api.validate:app", host="0.0.0.0", port=8000, log_level="info")

def run_telegram_bot():
    print("[+] Starting MYZO VIP Telegram Bot...")
    from bot.bot import main
    main()

if __name__ == "__main__":
    print("=" * 60)
    print("🔥 MYZO VIP LICENSE MANAGER & TELEGRAM BOT SYSTEM")
    print("📱 Synced with FOUGO EXTERNAL iOS IPA")
    print("=" * 60)
    
    # Start API in background thread
    api_thread = threading.Thread(target=run_fastapi, daemon=True)
    api_thread.start()
    
    time.sleep(1)
    
    # Start bot on main thread
    try:
        run_telegram_bot()
    except KeyboardInterrupt:
        print("\n[!] Shutting down server and bot...")
        sys.exit(0)
