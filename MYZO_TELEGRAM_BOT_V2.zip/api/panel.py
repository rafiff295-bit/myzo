import os
import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3
from fastapi import FastAPI, HTTPException, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from starlette.middleware.sessions import SessionMiddleware
from dotenv import load_dotenv

load_dotenv()
DB_PATH = os.getenv('DB_PATH', 'data/myzo.db')
PANEL_SECRET = os.getenv('PANEL_SECRET', '')
app = FastAPI(title='MYZO Control Panel')
app.add_middleware(SessionMiddleware, secret_key=PANEL_SECRET or secrets.token_urlsafe(32), max_age=86400)

QUANTITIES = [1,2,8,10,15,100]
DURATIONS = {'1h':timedelta(hours=1),'2h':timedelta(hours=2),'4h':timedelta(hours=4),'6h':timedelta(hours=6),'12h':timedelta(hours=12),'24h':timedelta(hours=24),'7d':timedelta(days=7),'30d':timedelta(days=30),'life':None}

def db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def init():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(telegram_id INTEGER PRIMARY KEY,name TEXT,role TEXT NOT NULL DEFAULT 'reseller',active INTEGER NOT NULL DEFAULT 1,credits INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS instances(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS licenses(key TEXT PRIMARY KEY,owner_id INTEGER NOT NULL,duration_value INTEGER NOT NULL,duration_unit TEXT NOT NULL,created_at TEXT NOT NULL,expires_at TEXT,active INTEGER NOT NULL DEFAULT 1,device_id TEXT DEFAULT '');
    CREATE TABLE IF NOT EXISTS license_instances(license_key TEXT NOT NULL,instance_id INTEGER NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(license_key,instance_id),FOREIGN KEY(license_key) REFERENCES licenses(key) ON DELETE CASCADE,FOREIGN KEY(instance_id) REFERENCES instances(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,actor_id INTEGER NOT NULL,actor_role TEXT NOT NULL,action TEXT NOT NULL,target TEXT DEFAULT '',details TEXT DEFAULT '',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS credit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,actor_id INTEGER NOT NULL,target_id INTEGER NOT NULL,amount INTEGER NOT NULL,reason TEXT DEFAULT '',created_at TEXT NOT NULL);
    '''); c.commit(); c.close()

init()

def now(): return datetime.now(timezone.utc).isoformat()
def audit(actor,role,action,target='',details=''):
    c=db(); c.execute('INSERT INTO audit(actor_id,actor_role,action,target,details,created_at) VALUES(?,?,?,?,?,?)',(actor,role,action,target,details,now())); c.commit(); c.close()
def keygen(): return 'MYZO-'+'-'.join(secrets.token_hex(3).upper() for _ in range(3))

def user_role(uid):
    owner_ids={int(x) for x in os.getenv('OWNER_IDS','').split(',') if x.strip()}
    if uid in owner_ids: return 'owner'
    c=db(); r=c.execute('SELECT role FROM users WHERE telegram_id=? AND active=1',(uid,)).fetchone(); c.close(); return r['role'] if r else None

def auth(request):
    role=request.session.get('role'); uid=request.session.get('uid')
    if not role or not uid: return None
    return role, int(uid)

def page(title, body, role):
    nav='<a href="/panel">Dashboard</a> <a href="/panel/keys">Keys</a> '
    if role=='owner': nav += '<a href="/panel/instances">Instances</a> <a href="/panel/users">Users</a>'
    return f'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>body{{font-family:system-ui;max-width:1050px;margin:auto;padding:18px;background:#f5f7fb}}nav,section{{background:white;padding:16px;margin:10px 0;border-radius:14px}}a{{margin-right:12px}}input,select,button{{padding:10px;margin:4px;border:1px solid #ccd;border-radius:8px}}table{{width:100%;border-collapse:collapse}}td,th{{padding:8px;border-bottom:1px solid #ddd;text-align:left}}</style></head><body><nav><b>MYZO Control Panel</b> — {role.upper()} | {nav}<a href="/panel/logout">Logout</a></nav>{body}</body></html>'''

@app.get('/panel/login',response_class=HTMLResponse)
def login_form():
    return '''<html><body style="font-family:system-ui;max-width:420px;margin:60px auto"><h2>MYZO Panel Login</h2><form method="post"><input name="telegram_id" placeholder="Telegram ID" required><input name="password" type="password" placeholder="Panel password" required><button>Login</button></form></body></html>'''

@app.post('/panel/login')
def login(telegram_id:int=Form(...),password:str=Form(...)):
    if not PANEL_SECRET or not secrets.compare_digest(password,PANEL_SECRET): raise HTTPException(401,'Invalid password')
    r=user_role(telegram_id)
    if r not in ('owner','admin','reseller'): raise HTTPException(403,'User is not authorized')
    resp=RedirectResponse('/panel',303); resp.set_cookie('legacy','1',httponly=True)
    # Session is set through a small internal response hook workaround below.
    return _login_response(telegram_id,r)

def _login_response(uid,role):
    resp=RedirectResponse('/panel',303); resp.set_cookie('uid',str(uid),httponly=True); resp.set_cookie('role',role,httponly=True); return resp

def cookie_auth(request):
    role=request.cookies.get('role'); uid=request.cookies.get('uid')
    if role in ('owner','admin','reseller') and uid and uid.isdigit() and user_role(int(uid))==role: return role,int(uid)
    return None

@app.get('/panel',response_class=HTMLResponse)
def dashboard(request):
    a=cookie_auth(request)
    if not a:return RedirectResponse('/panel/login',303)
    role,uid=a;c=db(); stats=[('Keys',c.execute('SELECT COUNT(*) n FROM licenses').fetchone()['n']),('Active keys',c.execute('SELECT COUNT(*) n FROM licenses WHERE active=1').fetchone()['n']),('Instances',c.execute('SELECT COUNT(*) n FROM instances WHERE active=1').fetchone()['n'])]
    if role=='owner': stats += [('Admins',c.execute("SELECT COUNT(*) n FROM users WHERE role='admin' AND active=1").fetchone()['n']),('Resellers',c.execute("SELECT COUNT(*) n FROM users WHERE role='reseller' AND active=1").fetchone()['n'])]
    c.close(); body='<h2>Dashboard</h2><section>'+''.join(f'<b>{k}</b>: {v} &nbsp; ' for k,v in stats)+'</section>'
    return page('Dashboard',body,role)

@app.get('/panel/keys',response_class=HTMLResponse)
def keys(request):
    a=cookie_auth(request)
    if not a:return RedirectResponse('/panel/login',303)
    role,uid=a;c=db(); rows=c.execute('SELECT key,duration_value,duration_unit,active,expires_at,owner_id FROM licenses '+('WHERE owner_id=? ' if role=='reseller' else '')+'ORDER BY created_at DESC LIMIT 200',((uid,) if role=='reseller' else ())).fetchall(); c.close()
    create='''<section><h3>Create keys</h3><form method="post" action="/panel/keys/create"><select name="quantity">''' + ''.join(f'<option>{q}</option>' for q in QUANTITIES) + '''</select><select name="duration">''' + ''.join(f'<option value="{k}">{k}</option>' for k in DURATIONS) + '''</select><div>Instances:</div>''' + _instance_checks() + '<button>Create</button></form></section>' if role in ('owner','admin','reseller') else ''
    table='<section><table><tr><th>Key</th><th>Duration</th><th>Status</th><th>Expires</th></tr>'+''.join(f"<tr><td>{x['key']}</td><td>{x['duration_value']}{x['duration_unit']}</td><td>{'ACTIVE' if x['active'] else 'DISABLED'}</td><td>{x['expires_at'] or 'Lifetime'}</td></tr>" for x in rows)+'</table></section>'
    return page('Keys',create+table,role)

def _instance_checks():
    c=db(); rows=c.execute('SELECT id,name,active FROM instances ORDER BY id').fetchall();c.close();return ''.join(f'<label><input type="checkbox" name="instance_ids" value="{x["id"]}" {"" if x["active"] else "disabled"}>{x["id"]}. {x["name"]}</label><br>' for x in rows)

@app.post('/panel/keys/create')
def create_keys(request,quantity:int=Form(...),duration:str=Form(...),instance_ids:list[int]=Form(default=[])):
    a=cookie_auth(request)
    if not a:return RedirectResponse('/panel/login',303)
    role,uid=a
    if quantity not in QUANTITIES or duration not in DURATIONS: raise HTTPException(400,'Invalid selection')
    c=db();
    if role=='reseller':
        bal=c.execute('SELECT credits FROM users WHERE telegram_id=?',(uid,)).fetchone()['credits']
        if bal<quantity:c.close();raise HTTPException(400,'Not enough credits')
        c.execute('UPDATE users SET credits=credits-? WHERE telegram_id=?',(quantity,uid))
    value=0 if duration=='life' else int(duration[:-1]);unit='life' if duration=='life' else duration[-1]; exp=None if duration=='life' else datetime.now(timezone.utc)+DURATIONS[duration]
    made=[]
    for _ in range(quantity):
        k=keygen()
        while c.execute('SELECT 1 FROM licenses WHERE key=?',(k,)).fetchone():k=keygen()
        c.execute('INSERT INTO licenses(key,owner_id,duration_value,duration_unit,created_at,expires_at,active,device_id) VALUES(?,?,?,?,?,?,?,?)',(k,uid,value,unit,now(),exp.isoformat() if exp else None,1,''))
        for iid in instance_ids:c.execute('INSERT OR IGNORE INTO license_instances(license_key,instance_id,created_at) VALUES(?,?,?)',(k,iid,now()))
        made.append(k)
    c.commit();c.close();audit(uid,role,'PANEL_CREATE_KEYS',','.join(made),f'quantity={quantity};duration={duration};instances={instance_ids}')
    return RedirectResponse('/panel/keys',303)

@app.get('/panel/instances',response_class=HTMLResponse)
def instances(request):
    a=cookie_auth(request)
    if not a or a[0]!='owner': return RedirectResponse('/panel',303)
    c=db();rows=c.execute('SELECT * FROM instances ORDER BY id').fetchall();c.close()
    body='''<h2>Instances</h2><section><form method="post" action="/panel/instances/add"><input name="name" placeholder="Instance name" required><button>Add</button></form></section><section><table><tr><th>ID</th><th>Name</th><th>Status</th><th>Actions</th></tr>'''
    for x in rows: body+=f'''<tr><td>{x['id']}</td><td>{x['name']}</td><td>{'ACTIVE' if x['active'] else 'DISABLED'}</td><td><form style="display:inline" method="post" action="/panel/instances/toggle"><input type="hidden" name="id" value="{x['id']}"><button>Toggle</button></form><form style="display:inline" method="post" action="/panel/instances/rename"><input type="hidden" name="id" value="{x['id']}"><input name="name" placeholder="New name" required><button>Rename</button></form><form style="display:inline" method="post" action="/panel/instances/delete"><input type="hidden" name="id" value="{x['id']}"><button>Delete</button></form></td></tr>'''
    body+='</table></section>';return page('Instances',body,'owner')

@app.post('/panel/instances/add')
def add_instance(request,name:str=Form(...)):
    a=cookie_auth(request)
    if not a or a[0]!='owner': raise HTTPException(403,'Owner only')
    c=db();
    try:c.execute('INSERT INTO instances(name,active,created_at,updated_at) VALUES(?,?,?,?)',(name.strip(),1,now(),now()));c.commit()
    except sqlite3.IntegrityError: c.close();raise HTTPException(400,'Instance already exists')
    c.close();audit(a[1],'owner','PANEL_ADD_INSTANCE',name.strip());return RedirectResponse('/panel/instances',303)

@app.post('/panel/instances/toggle')
def toggle_instance(request,id:int=Form(...)):
    a=cookie_auth(request)
    if not a or a[0]!='owner': raise HTTPException(403,'Owner only')
    c=db();c.execute('UPDATE instances SET active=CASE active WHEN 1 THEN 0 ELSE 1 END,updated_at=? WHERE id=?',(now(),id));c.commit();c.close();return RedirectResponse('/panel/instances',303)

@app.post('/panel/instances/rename')
def rename_instance(request,id:int=Form(...),name:str=Form(...)):
    a=cookie_auth(request)
    if not a or a[0]!='owner': raise HTTPException(403,'Owner only')
    c=db();c.execute('UPDATE instances SET name=?,updated_at=? WHERE id=?',(name.strip(),now(),id));c.commit();c.close();return RedirectResponse('/panel/instances',303)

@app.post('/panel/instances/delete')
def delete_instance(request,id:int=Form(...)):
    a=cookie_auth(request)
    if not a or a[0]!='owner': raise HTTPException(403,'Owner only')
    c=db();c.execute('DELETE FROM instances WHERE id=?',(id,));c.commit();c.close();return RedirectResponse('/panel/instances',303)

@app.get('/panel/users',response_class=HTMLResponse)
def users(request):
    a=cookie_auth(request)
    if not a or a[0]!='owner':return RedirectResponse('/panel',303)
    c=db();rows=c.execute('SELECT telegram_id,name,role,active,credits FROM users ORDER BY role,telegram_id').fetchall();c.close()
    body='''<h2>Users</h2><section><form method="post" action="/panel/users/add"><input name="telegram_id" placeholder="Telegram ID" required><select name="role"><option>admin</option><option>reseller</option></select><button>Add / Reactivate</button></form></section><section><table><tr><th>ID</th><th>Role</th><th>Active</th><th>Credits</th></tr>'''+''.join(f"<tr><td>{x['telegram_id']}</td><td>{x['role']}</td><td>{x['active']}</td><td>{x['credits']}</td></tr>" for x in rows)+'</table></section>'
    return page('Users',body,'owner')

@app.post('/panel/users/add')
def add_user(request,telegram_id:int=Form(...),role:str=Form(...)):
    a=cookie_auth(request)
    if not a or a[0]!='owner' or role not in ('admin','reseller'):raise HTTPException(403,'Owner only')
    c=db();c.execute('INSERT INTO users(telegram_id,name,role,active,credits,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(telegram_id) DO UPDATE SET role=excluded.role,active=1',(telegram_id,'',role,1,0,now()));c.commit();c.close();return RedirectResponse('/panel/users',303)

@app.get('/panel/logout')
def logout(request):
    r=RedirectResponse('/panel/login',303);r.delete_cookie('uid');r.delete_cookie('role');return r
