import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="MYZO License API")
SECRET = os.getenv("API_SECRET", "")
DB_PATH = os.getenv("DB_PATH", "data/myzo.db")


def db_conn():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def is_valid(row):
    if not row["active"]:
        return False
    if row["expires_at"] is None:
        return True
    return datetime.fromisoformat(row["expires_at"]) > datetime.now(timezone.utc)


@app.get("/health")
def health():
    return {"ok": True, "service": "MYZO License API"}


@app.get("/validate")
def validate(key: str, device_id: str = "", x_api_secret: str = Header(default="")):
    if SECRET and x_api_secret and x_api_secret != SECRET:
        raise HTTPException(401, "Unauthorized")
    key = key.strip().upper()
    db = db_conn()
    row = db.execute(
        "SELECT key,active,duration_value,duration_unit,created_at,expires_at,device_id FROM licenses WHERE key=?",
        (key,),
    ).fetchone()
    if not row:
        db.close()
        return {"valid": False, "reason": "not_found", "message": "Invalid Key. Not found in system.", "instances": []}

    valid = is_valid(row)
    if not valid:
        db.close()
        reason = "disabled" if not row["active"] else "expired"
        return {"valid": False, "reason": reason, "message": f"Key is {reason.upper()}.", "key": row["key"], "expires_at": row["expires_at"]}

    # Device ID Hardware Binding
    bound_device = row["device_id"] or ""
    if device_id:
        device_id = device_id.strip()
        if not bound_device:
            # First time use -> bind to this hardware
            db.execute("UPDATE licenses SET device_id=? WHERE key=?", (device_id, key))
            db.commit()
            bound_device = device_id
        elif bound_device != device_id:
            db.close()
            return {
                "valid": False,
                "reason": "device_mismatch",
                "message": "Key is locked to another device. Contact seller to reset HWID.",
                "bound_device": bound_device,
            }

    inst = db.execute(
        "SELECT i.id,i.name,i.active FROM instances i JOIN license_instances li ON li.instance_id=i.id WHERE li.license_key=? ORDER BY i.id",
        (key,),
    ).fetchall()
    allowed_ids = {x["id"] for x in inst if x["active"]}
    all_inst = db.execute("SELECT id,name,active FROM instances ORDER BY id").fetchall()
    db.close()

    return {
        "valid": True,
        "reason": "ok",
        "key": row["key"],
        "device_id": bound_device,
        "expires_at": row["expires_at"],
        "duration": {"value": row["duration_value"], "unit": row["duration_unit"]},
        "instances": [
            {"id": x["id"], "name": x["name"], "allowed": x["id"] in allowed_ids}
            for x in all_inst
        ],
    }
