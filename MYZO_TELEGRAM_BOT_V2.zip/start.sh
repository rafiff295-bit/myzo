#!/usr/bin/env bash
set -e
echo "Starting MYZO VIP Telegram Bot & License API..."
pip install -r requirements.txt
python3 start_all.py
