@echo off
title MYZO VIP BOT & LICENSE SERVER
echo Installing requirements...
python -m pip install -r requirements.txt
echo Starting Telegram Bot & API Server...
python start_all.py
pause
