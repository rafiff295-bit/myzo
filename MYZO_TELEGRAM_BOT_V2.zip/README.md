# 👑 MYZO VIP Telegram Bot & License Panel

Complete Key Management & License Verification System for **FOUGO EXTERNAL (iOS IPA)**.

---

## 🚀 Features

- **Hierarchical Access Levels**:
  - 👑 **Owner**: Full access. Add/remove Admins and Sellers, manage instances, adjust credits, purge expired keys, view audit logs.
  - 🛡️ **Admin**: Create keys, manage all seller keys, add sellers, allocate credits, inspect system stats.
  - 💼 **Seller (Reseller)**: Create keys using credit balance, view and manage their own keys, reset HWID for buyers, extend durations, and revoke keys.
- **Full Key Lifecycle Management**:
  - **Create**: Interactive wizard (`/create`) or quick 1-click generator (`/quick 30d`, `/quick 7d`, `/quick life`).
  - **Edit / Extend**: Extend any license expiry (`/edit <KEY> <DAYS>`).
  - **Reset HWID**: Unbind device ID so the buyer can move the key to a new phone (`/resethwid <KEY>`).
  - **Enable / Disable**: Temporarily pause or re-activate access (`/disable <KEY>`, `/enable <KEY>`).
  - **Revoke / Delete**: Permanently delete keys (`/revoke <KEY>`).
  - **Interactive Buttons**: `/check <KEY>` opens inline buttons for instant 1-tap editing!
- **100% Cryptographic IPA Synchronization**:
  - Every generated key uses the salted SHA-256 scheme:
    `MYZO-<TIER>-<SEED>-<HASH4>`
  - Matches the `MYZOVerify()` algorithm built into the iOS App `main.m`!
  - Also verified online via FastAPI (`/validate?key=...&device_id=...`).

---

## 🛠️ Setup & Running

### 1. Requirements
- Python 3.10+
- Telegram Bot Token from [@BotFather](https://t.me/BotFather)
- Your Telegram User ID from [@userinfobot](https://t.me/userinfobot)

### 2. Configure `.env`
Create a `.env` file in this directory (or edit `.env.example`):
```env
BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN_FROM_BOTFATHER
OWNER_IDS=YOUR_TELEGRAM_USER_ID
API_SECRET=myzo_super_secret_key_9973
PANEL_SECRET=panel_admin_password_2026
```

### 3. Launch
- **Windows**: Double-click `run.bat`
- **Linux / VPS / Mac**:
  ```bash
  chmod +x start.sh
  ./start.sh
  ```
  Or:
  ```bash
  pip install -r requirements.txt
  python3 start_all.py
  ```

---

## 📱 Bot Command List

| Command | Role | Description |
|---|---|---|
| `/start` | All | View profile, role, credits, and available commands |
| `/create` | All | Interactive 3-step key creation wizard |
| `/quick <1h\|7d\|30d\|life>` | All | Fast 1-click key creation |
| `/list` | All | List your active licenses |
| `/check <key>` | All | Open interactive Key Editor (HWID, Duration, Delete) |
| `/edit <key> <days>` | All | Add extra days to a license |
| `/resethwid <key>` | All | Clear bound device ID (allow new phone login) |
| `/enable <key>` | All | Re-activate a disabled key |
| `/disable <key>` | All | Pause/disable key access |
| `/revoke <key>` | All | Delete key permanently |
| `/addseller <tg_id>` | Admin/Owner | Register a new reseller/seller |
| `/addadmin <tg_id>` | Owner | Appoint a new Admin |
| `/credits <tg_id> <amt>` | Admin/Owner | Recharge or deduct seller credits |
| `/users` | Admin/Owner | List all registered sellers & admins |
| `/stats` | Admin/Owner | Total keys, active licenses, and sellers |
| `/deleteall` | Owner | Purge all expired keys from database |

---

## 🌐 API Verification Endpoint (Port 8000)
- `GET /health` -> `{"ok": true}`
- `GET /validate?key=MYZO-30D-...&device_id=PHONE_UUID` -> Returns validity, expiration, and binds hardware ID.
