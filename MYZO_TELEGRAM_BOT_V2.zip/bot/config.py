import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN") or "8972996495:AAHzb0e-FbXZAL227729BoEC-tGUncbG7cc"
raw_owners = os.getenv("OWNER_IDS") or "8245269289"
OWNER_IDS = {int(x.strip()) for x in raw_owners.split(",") if x.strip() and x.strip().isdigit()}
API_SECRET = os.getenv("API_SECRET", "FOUGO_VIP_SECRET_9973")
DB_PATH = os.getenv("DB_PATH", "data/myzo.db")
