import hashlib
import os
import re
import secrets
from datetime import datetime, timedelta, timezone

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    Update,
)
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from bot.config import BOT_TOKEN, OWNER_IDS
from bot.db import (
    audit,
    conn,
    delete_all_expired,
    delete_key,
    extend_key,
    get_key,
    get_user,
    init,
    list_users,
    now,
    reset_hwid,
    revoke_user,
    revoke_user_keys,
    set_all_active_by_role,
    set_lifetime,
    set_user_active,
    toggle_key,
)

# Salt for FOUGO EXTERNAL / MYZO IPA (100% matched with iOS main.m)
IPA_SALT = "@MYZO_PANEL_ENCRYPTED_SALT_9973"

DURATIONS = [
    (1, "h", "1 Hour", "1H"),
    (24, "h", "24 Hours (1 Day)", "1D"),
    (7, "d", "7 Days (1 Week)", "7D"),
    (30, "d", "30 Days (1 Month)", "30D"),
    (0, "life", "👑 Lifetime VIP", "VIP"),
]


def role(uid: int) -> str | None:
    if uid in OWNER_IDS:
        return "owner"
    c = conn()
    r = c.execute("SELECT role, active FROM users WHERE telegram_id=?", (uid,)).fetchone()
    c.close()
    if r and r["active"]:
        return r["role"]
    return None


def get_user_credits(uid: int, user_role: str) -> int:
    if user_role in ("owner", "admin"):
        return 999999
    c = conn()
    r = c.execute("SELECT credits FROM users WHERE telegram_id=?", (uid,)).fetchone()
    c.close()
    return r["credits"] if r else 0


# Cryptographic Key Generator (100% matched with iOS IPA salted SHA-256 validation)
def make_fougo_key(tier: str = "VIP") -> str:
    tier = tier.upper()
    seed = secrets.token_hex(4).upper()
    raw = f"MYZO:{tier}:{seed}:{IPA_SALT}"
    h4 = hashlib.sha256(raw.encode()).hexdigest()[:4].upper()
    return f"MYZO-{tier}-{seed}-{h4}"


def expiry_for(value: int, unit: str):
    if unit == "life":
        return None
    delta = timedelta(hours=value) if unit == "h" else timedelta(days=value)
    return datetime.now(timezone.utc) + delta


# ==================== KEYBOARDS (ENGLISH ONLY • ALL BUTTONS) ====================

def main_reply_keyboard(user_role: str) -> ReplyKeyboardMarkup:
    """Bottom persistent reply keyboard — 100% English buttons."""
    if user_role == "owner":
        kb = [
            [KeyboardButton("⚡ Create Key"), KeyboardButton("🔑 Manage Keys")],
            [KeyboardButton("📱 Reset HWID"), KeyboardButton("⏳ Extend Key")],
            [KeyboardButton("🗑️ Delete Key"), KeyboardButton("👥 Admin & Seller Panel")],
            [KeyboardButton("🧹 Purge Expired"), KeyboardButton("📊 System Stats")],
        ]
    elif user_role == "admin":
        kb = [
            [KeyboardButton("⚡ Create Key"), KeyboardButton("🔑 Manage Keys")],
            [KeyboardButton("📱 Reset HWID"), KeyboardButton("⏳ Extend Key")],
            [KeyboardButton("🗑️ Delete Key"), KeyboardButton("💼 Sellers & Credits")],
            [KeyboardButton("📊 System Stats")],
        ]
    else:  # reseller / seller
        kb = [
            [KeyboardButton("⚡ Create Key"), KeyboardButton("🔑 My Keys")],
            [KeyboardButton("📱 Reset HWID"), KeyboardButton("⏳ Extend Key")],
            [KeyboardButton("🗑️ Delete Key"), KeyboardButton("💳 My Balance")],
        ]
    return ReplyKeyboardMarkup(kb, resize_keyboard=True)


def create_duration_inline_keyboard() -> InlineKeyboardMarkup:
    buttons = [
        [
            InlineKeyboardButton("⚡ 1 Hour", callback_data="gen_dur:1:h:1H"),
            InlineKeyboardButton("⚡ 24 Hours (1 Day)", callback_data="gen_dur:24:h:1D"),
        ],
        [
            InlineKeyboardButton("⚡ 7 Days", callback_data="gen_dur:7:d:7D"),
            InlineKeyboardButton("⚡ 30 Days", callback_data="gen_dur:30:d:30D"),
        ],
        [
            InlineKeyboardButton("👑 Lifetime VIP", callback_data="gen_dur:0:life:VIP"),
        ],
        [
            InlineKeyboardButton("❌ Cancel", callback_data="menu_home"),
        ],
    ]
    return InlineKeyboardMarkup(buttons)


def key_detail_keyboard(key: str, active: int, bound_device: str | None = None) -> InlineKeyboardMarkup:
    status_label = "🔴 Disable Key" if active else "🟢 Enable Key"
    rows = [
        [
            InlineKeyboardButton(status_label, callback_data=f"act_toggle:{key}"),
            InlineKeyboardButton("📱 Reset HWID (Unlock)", callback_data=f"act_hwid:{key}"),
        ],
        [
            InlineKeyboardButton("⏳ +7 Days", callback_data=f"act_ext:{key}:7"),
            InlineKeyboardButton("⏳ +30 Days", callback_data=f"act_ext:{key}:30"),
            InlineKeyboardButton("♾️ Lifetime VIP", callback_data=f"act_ext:{key}:life"),
        ],
        [
            InlineKeyboardButton("🗑️ Revoke & Delete Key", callback_data=f"act_del_confirm:{key}"),
        ],
        [
            InlineKeyboardButton("🔙 Back to Keys", callback_data="nav_keys_list"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home"),
        ],
    ]
    return InlineKeyboardMarkup(rows)


# ==================== DASHBOARD & HOME ====================

async def show_home(target_message, user_id: int, user_role: str, is_edit: bool = False):
    credits_val = get_user_credits(user_id, user_role)
    balance_text = "Unlimited (Owner/Admin)" if user_role in ("owner", "admin") else f"{credits_val} Credits"

    text = (
        "👑 *FOUGO EXTERNAL • VIP LICENSE CONTROL PANEL*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 *User ID:* `{user_id}`\n"
        f"🎖️ *Your Role:* *{user_role.upper()}*\n"
        f"💳 *Balance:* `{balance_text}`\n"
        f"📱 *Target App:* `FOUGO EXTERNAL (iOS)`\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💡 *Use the buttons below to create, manage, extend, reset HWID, or revoke keys:*"
    )

    inline_kb = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("⚡ Quick Create Key", callback_data="nav_create"),
            InlineKeyboardButton("🔑 Manage Keys", callback_data="nav_keys_list"),
        ],
        [
            InlineKeyboardButton("📱 Reset HWID", callback_data="nav_hwid_list"),
            InlineKeyboardButton("⏳ Extend Key", callback_data="nav_extend_list"),
        ],
        [
            InlineKeyboardButton("🗑️ Delete Key", callback_data="nav_delete_list"),
            InlineKeyboardButton("📊 System Stats", callback_data="nav_stats"),
        ],
    ])

    if is_edit:
        try:
            await target_message.edit_text(text, parse_mode="Markdown", reply_markup=inline_kb)
            return
        except Exception:
            pass

    await target_message.reply_text(
        text,
        parse_mode="Markdown",
        reply_markup=main_reply_keyboard(user_role),
    )


# ==================== CREATE KEY (BUTTON DRIVEN) ====================

async def handle_create_key_button(target_message, user_id: int, user_role: str):
    credits_val = get_user_credits(user_id, user_role)
    if user_role == "reseller" and credits_val < 1:
        text = "❌ *Insufficient Credits!*\nPlease contact the Owner (@MYZO_PANEL) to recharge your balance."
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")]])
        return await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)

    text = (
        "⚡ *SELECT VIP KEY DURATION:*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Choose key duration from the buttons below:"
    )
    await target_message.reply_text(text, parse_mode="Markdown", reply_markup=create_duration_inline_keyboard())


async def execute_key_generation(update: Update, context: ContextTypes.DEFAULT_TYPE, value: int, unit: str, tier: str):
    query = update.callback_query
    await query.answer()
    uid = update.effective_user.id
    r = role(uid)
    if not r:
        return await query.edit_text("⛔ Access denied.")

    db = conn()
    if r == "reseller":
        user_row = db.execute("SELECT credits FROM users WHERE telegram_id=?", (uid,)).fetchone()
        if not user_row or user_row["credits"] < 1:
            db.close()
            return await query.edit_text("❌ Insufficient credits.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")]]))
        db.execute("UPDATE users SET credits=credits-1 WHERE telegram_id=?", (uid,))

    key = make_fougo_key(tier)
    exp = expiry_for(value, unit)
    exp_iso = exp.isoformat() if exp else None
    dur_str = f"{value} Hour(s)" if unit == "h" else (f"{value} Day(s)" if unit == "d" else "Lifetime")

    db.execute(
        "INSERT INTO licenses(key,owner_id,tier,max_instances,active,expires_at,created_at) VALUES(?,?,?,?,?,?,?)",
        (key, uid, tier, 1, 1, exp_iso, now()),
    )
    db.commit()
    db.close()

    audit(uid, r, "CREATE_KEY", key, f"duration={dur_str}")

    exp_display = exp.strftime("%Y-%m-%d %H:%M UTC") if exp else "♾️ Lifetime VIP (No Expiry)"

    text = (
        "🎉 *NEW VIP LICENSE KEY GENERATED!*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔑 *KEY:* `{key}`\n"
        f"⏳ *Duration:* `{dur_str}`\n"
        f"📅 *Expires At:* `{exp_display}`\n"
        f"📱 *Hardware Lock:* `Automatically binds on first login`\n"
        f"🛡️ *Target App:* `FOUGO EXTERNAL (iOS)`\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "📋 *Tap the key above to copy and send to buyer.*"
    )

    action_kb = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📱 Reset HWID", callback_data=f"act_hwid:{key}"),
            InlineKeyboardButton("⏳ Extend Duration", callback_data=f"act_ext_select:{key}"),
        ],
        [
            InlineKeyboardButton("🔴 Disable Key", callback_data=f"act_toggle:{key}"),
            InlineKeyboardButton("🗑️ Revoke Key", callback_data=f"act_del_confirm:{key}"),
        ],
        [
            InlineKeyboardButton("⚡ Create Another Key", callback_data="nav_create"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home"),
        ],
    ])

    await query.edit_text(text, parse_mode="Markdown", reply_markup=action_kb)


# ==================== KEY MANAGEMENT LIST (BUTTON DRIVEN) ====================

async def handle_list_keys(target_message, user_id: int, user_role: str, is_edit: bool = False):
    db = conn()
    if user_role == "reseller":
        rows = db.execute("SELECT * FROM licenses WHERE owner_id=? ORDER BY id DESC LIMIT 12", (user_id,)).fetchall()
    else:
        rows = db.execute("SELECT * FROM licenses ORDER BY id DESC LIMIT 12").fetchall()
    db.close()

    if not rows:
        text = "📭 *No keys found!*\nCreate your first VIP key using the button below:"
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("⚡ Create New Key", callback_data="nav_create")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")],
        ])
        if is_edit:
            return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
        return await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)

    text = (
        "🔑 *VIP KEYS CONTROL PANEL:*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Click any key below to edit, reset device HWID, or delete:\n"
        "*(🟢 Active | 🔴 Disabled | 📱 Device Locked)*"
    )

    buttons = []
    for r in rows:
        k = r["key"]
        st = "🟢" if r["active"] else "🔴"
        hwid_icon = "📱" if r["device_id"] else "🔓"
        short_k = f"{k[:12]}...{k[-4:]}"
        label = f"{st} {hwid_icon} {short_k} ({r['tier']})"
        buttons.append([InlineKeyboardButton(label, callback_data=f"view_key:{k}")])

    buttons.append([
        InlineKeyboardButton("⚡ Create New Key", callback_data="nav_create"),
        InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home"),
    ])

    kb = InlineKeyboardMarkup(buttons)
    if is_edit:
        return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
    await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)


async def handle_view_single_key(query, key: str, user_id: int, user_role: str):
    row = get_key(key)
    if not row:
        return await query.edit_text("❌ Key not found.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back to Keys", callback_data="nav_keys_list")]]))

    if user_role == "reseller" and row["owner_id"] != user_id:
        return await query.edit_text("⛔ You can only manage keys created by your own account.")

    st = "🟢 ACTIVE" if row["active"] else "🔴 DISABLED"
    hwid_text = f"📱 Bound to (`{row['device_id']}`)" if row["device_id"] else "🔓 Open (Not locked to any device yet)"
    exp_text = row["expires_at"][:19] + " UTC" if row["expires_at"] else "♾️ Lifetime VIP"

    text = (
        "🔑 *KEY DETAILS & ACTIONS:*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        f"• *Key:* `{key}`\n"
        f"• *Status:* {st}\n"
        f"• *Expires:* `{exp_text}`\n"
        f"• *HWID Lock:* {hwid_text}\n"
        f"• *Created:* `{row['created_at'][:19]}`\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👇 *Tap any button below for 1-click action:*"
    )

    await query.edit_text(text, parse_mode="Markdown", reply_markup=key_detail_keyboard(key, row["active"], row["device_id"]))


# ==================== HWID RESET (BUTTON DRIVEN) ====================

async def handle_hwid_menu(target_message, user_id: int, user_role: str, is_edit: bool = False):
    db = conn()
    if user_role == "reseller":
        rows = db.execute("SELECT * FROM licenses WHERE owner_id=? AND device_id IS NOT NULL AND device_id != '' ORDER BY id DESC LIMIT 10", (user_id,)).fetchall()
    else:
        rows = db.execute("SELECT * FROM licenses WHERE device_id IS NOT NULL AND device_id != '' ORDER BY id DESC LIMIT 10").fetchall()
    db.close()

    if not rows:
        text = "📱 *No keys are currently locked to any device!*\nAll keys are free to be activated on any phone."
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔑 View All Keys", callback_data="nav_keys_list")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")],
        ])
        if is_edit:
            return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
        return await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)

    text = (
        "📱 *DEVICE HWID UNLOCK PANEL:*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Select a key below to instantly clear its hardware lock:\n"
        "*(Allows buyer to login on a different iPhone)*"
    )

    buttons = []
    for r in rows:
        k = r["key"]
        short_k = f"{k[:12]}...{k[-4:]}"
        buttons.append([InlineKeyboardButton(f"📱 Unlock HWID: {short_k}", callback_data=f"act_hwid:{k}")])

    buttons.append([InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")])
    kb = InlineKeyboardMarkup(buttons)

    if is_edit:
        return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
    await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)


# ==================== EXTEND DURATION (BUTTON DRIVEN) ====================

async def handle_extend_menu(target_message, user_id: int, user_role: str, is_edit: bool = False):
    db = conn()
    if user_role == "reseller":
        rows = db.execute("SELECT * FROM licenses WHERE owner_id=? ORDER BY id DESC LIMIT 10", (user_id,)).fetchall()
    else:
        rows = db.execute("SELECT * FROM licenses ORDER BY id DESC LIMIT 10").fetchall()
    db.close()

    if not rows:
        text = "📭 No keys found."
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")]])
        if is_edit:
            return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
        return await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)

    text = "⏳ *Select a key to extend its duration:*"
    buttons = []
    for r in rows:
        k = r["key"]
        short_k = f"{k[:12]}...{k[-4:]}"
        buttons.append([InlineKeyboardButton(f"⏳ {short_k}", callback_data=f"act_ext_select:{k}")])

    buttons.append([InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")])
    kb = InlineKeyboardMarkup(buttons)

    if is_edit:
        return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
    await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)


async def show_duration_extension_options(query, key: str):
    text = (
        f"⏳ *Choose Duration Extension:*\n"
        f"🔑 *Key:* `{key}`\n\n"
        f"Tap any button below to instantly add time:"
    )
    buttons = [
        [
            InlineKeyboardButton("➕ 7 Days", callback_data=f"act_ext:{key}:7"),
            InlineKeyboardButton("➕ 30 Days", callback_data=f"act_ext:{key}:30"),
        ],
        [
            InlineKeyboardButton("➕ 90 Days", callback_data=f"act_ext:{key}:90"),
            InlineKeyboardButton("👑 Lifetime VIP", callback_data=f"act_ext:{key}:life"),
        ],
        [
            InlineKeyboardButton("🔙 Back to Keys", callback_data="nav_keys_list"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home"),
        ],
    ]
    await query.edit_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))


# ==================== DELETE KEY (BUTTON DRIVEN) ====================

async def handle_delete_menu(target_message, user_id: int, user_role: str, is_edit: bool = False):
    db = conn()
    if user_role == "reseller":
        rows = db.execute("SELECT * FROM licenses WHERE owner_id=? ORDER BY id DESC LIMIT 10", (user_id,)).fetchall()
    else:
        rows = db.execute("SELECT * FROM licenses ORDER BY id DESC LIMIT 10").fetchall()
    db.close()

    if not rows:
        text = "📭 No keys found."
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")]])
        if is_edit:
            return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
        return await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)

    text = "🗑️ *Select a key to revoke & delete permanently:*"
    buttons = []
    for r in rows:
        k = r["key"]
        short_k = f"{k[:12]}...{k[-4:]}"
        buttons.append([InlineKeyboardButton(f"🗑️ Delete: {short_k}", callback_data=f"act_del_confirm:{k}")])

    buttons.append([InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")])
    kb = InlineKeyboardMarkup(buttons)

    if is_edit:
        return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
    await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)


# ==================== SYSTEM STATS (BUTTON DRIVEN) ====================

async def handle_stats(target_message, user_id: int, user_role: str, is_edit: bool = False):
    db = conn()
    total_keys = db.execute("SELECT COUNT(*) n FROM licenses").fetchone()["n"]
    active_keys = db.execute("SELECT COUNT(*) n FROM licenses WHERE active=1").fetchone()["n"]
    bound_devices = db.execute("SELECT COUNT(*) n FROM licenses WHERE device_id IS NOT NULL AND device_id != ''").fetchone()["n"]
    sellers = db.execute("SELECT COUNT(*) n FROM users WHERE role='reseller' AND active=1").fetchone()["n"]
    admins = db.execute("SELECT COUNT(*) n FROM users WHERE role='admin' AND active=1").fetchone()["n"]
    blocked_users = db.execute("SELECT COUNT(*) n FROM users WHERE active=0").fetchone()["n"]
    db.close()

    text = (
        "📊 *FOUGO VIP SYSTEM STATISTICS*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔑 *Total Licenses:* `{total_keys}`\n"
        f"🟢 *Active Licenses:* `{active_keys}`\n"
        f"📱 *Device-Locked Licenses:* `{bound_devices}`\n"
        f"💼 *Active Sellers:* `{sellers}`\n"
        f"🛡️ *Active Admins:* `{admins}`\n"
        f"🚫 *Blocked Accounts:* `{blocked_users}`\n"
        f"👑 *System Owner:* `@MYZO_PANEL`\n"
        f"📱 *Target App:* `FOUGO EXTERNAL (iOS)`\n"
        "━━━━━━━━━━━━━━━━━━━━━━"
    )

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 Refresh Stats", callback_data="nav_stats")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")],
    ])

    if is_edit:
        return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
    await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)


# ==================== OWNER PANEL: MANAGE ADMINS & SELLERS (BLOCK / UNBLOCK / REVOKE ALL) ====================

async def handle_roles_menu(target_message, user_id: int, user_role: str, is_edit: bool = False):
    if user_role not in ("owner", "admin"):
        return

    text = (
        "👥 *ROLE & USER ACCESS MANAGEMENT:*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Select management section below:"
    )

    buttons = []
    if user_role == "owner":
        buttons.append([
            InlineKeyboardButton("🛡️ Manage Admins (Block/Revoke)", callback_data="role_list:admin"),
            InlineKeyboardButton("💼 Manage Sellers (Block/Revoke)", callback_data="role_list:reseller"),
        ])
        buttons.append([
            InlineKeyboardButton("➕ Add New Admin", callback_data="role_add_admin"),
            InlineKeyboardButton("➕ Add New Seller", callback_data="role_add_seller"),
        ])
        buttons.append([
            InlineKeyboardButton("💳 Refill Seller Credits", callback_data="role_set_credits"),
            InlineKeyboardButton("⚡ Bulk Actions (Block/Unblock All)", callback_data="role_bulk_menu"),
        ])
        buttons.append([
            InlineKeyboardButton("🧹 Purge Expired Keys", callback_data="role_purge_expired"),
        ])
    else:  # Admin
        buttons.append([
            InlineKeyboardButton("💼 Manage Sellers", callback_data="role_list:reseller"),
            InlineKeyboardButton("➕ Add New Seller", callback_data="role_add_seller"),
        ])
        buttons.append([
            InlineKeyboardButton("💳 Refill Seller Credits", callback_data="role_set_credits"),
        ])

    buttons.append([InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home")])
    kb = InlineKeyboardMarkup(buttons)

    if is_edit:
        return await target_message.edit_text(text, parse_mode="Markdown", reply_markup=kb)
    await target_message.reply_text(text, parse_mode="Markdown", reply_markup=kb)


async def handle_user_list_by_role(query, target_role: str, user_role: str):
    rows = list_users(target_role)
    title = "🛡️ ADMINS LIST" if target_role == "admin" else "💼 SELLERS LIST"

    if not rows:
        text = f"{title}:\n━━━━━━━━━━━━━━━━━━━━━━\nNo {target_role} accounts found."
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton(f"➕ Add New {target_role.capitalize()}", callback_data=f"role_add_{target_role}")],
            [InlineKeyboardButton("🔙 Back to Roles", callback_data="nav_roles_panel")],
        ])
        return await query.edit_text(text, parse_mode="Markdown", reply_markup=kb)

    text = (
        f"{title}:\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Click any user below to Block, Unblock, Adjust Credits, or Revoke:"
    )

    buttons = []
    for u in rows:
        tg_id = u["telegram_id"]
        status_icon = "🟢" if u["active"] else "🔴 (BLOCKED)"
        cred_info = f" • {u['credits']} cr" if target_role == "reseller" else ""
        label = f"{status_icon} ID: {tg_id}{cred_info}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"user_detail:{tg_id}")])

    buttons.append([
        InlineKeyboardButton(f"➕ Add New {target_role.capitalize()}", callback_data=f"role_add_{target_role}"),
        InlineKeyboardButton("🔙 Back", callback_data="nav_roles_panel"),
    ])

    await query.edit_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))


async def handle_single_user_detail(query, target_id: int, caller_role: str):
    user_row = get_user(target_id)
    if not user_row:
        return await query.edit_text("❌ User not found.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="nav_roles_panel")]]))

    tg_id = user_row["telegram_id"]
    u_role = user_row["role"]
    is_active = user_row["active"]
    status_label = "🟢 ACTIVE" if is_active else "🔴 BLOCKED / DISABLED"
    toggle_btn_label = "🚫 Block User" if is_active else "🟢 Unblock User"

    text = (
        f"👤 *USER ACCOUNT INSPECTOR:*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        f"• *Telegram ID:* `{tg_id}`\n"
        f"• *Role:* *{u_role.upper()}*\n"
        f"• *Status:* {status_label}\n"
        f"• *Credits Balance:* `{user_row['credits']}`\n"
        f"• *Registered:* `{user_row['created_at'][:19]}`\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Select an action below:"
    )

    buttons = [
        [
            InlineKeyboardButton(toggle_btn_label, callback_data=f"user_toggle_active:{tg_id}"),
            InlineKeyboardButton("💳 Adjust Credits", callback_data=f"user_credit_prompt:{tg_id}"),
        ],
        [
            InlineKeyboardButton("🔑 Revoke All User's Keys", callback_data=f"user_revoke_keys_confirm:{tg_id}"),
        ],
        [
            InlineKeyboardButton("🗑️ Revoke / Delete Account", callback_data=f"user_revoke_account_confirm:{tg_id}"),
        ],
        [
            InlineKeyboardButton(f"🔙 Back to {u_role.capitalize()}s", callback_data=f"role_list:{u_role}"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home"),
        ],
    ]

    await query.edit_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))


async def handle_bulk_actions_menu(query, caller_role: str):
    if caller_role != "owner":
        return await query.answer("Owner only!", show_alert=True)

    text = (
        "⚡ *BULK USER ACCESS MANAGEMENT (OWNER ONLY)*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Execute bulk operations across all accounts:"
    )

    buttons = [
        [
            InlineKeyboardButton("🚫 Block ALL Sellers", callback_data="bulk_exec:reseller:0"),
            InlineKeyboardButton("🟢 Unblock ALL Sellers", callback_data="bulk_exec:reseller:1"),
        ],
        [
            InlineKeyboardButton("🚫 Block ALL Admins", callback_data="bulk_exec:admin:0"),
            InlineKeyboardButton("🟢 Unblock ALL Admins", callback_data="bulk_exec:admin:1"),
        ],
        [
            InlineKeyboardButton("🧹 Purge Expired Licenses", callback_data="role_purge_expired"),
        ],
        [
            InlineKeyboardButton("🔙 Back to Roles", callback_data="nav_roles_panel"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="menu_home"),
        ],
    ]

    await query.edit_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))


# ==================== MASTER CALLBACK DISPATCHER ====================

async def master_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    uid = update.effective_user.id
    r = role(uid)
    if not r:
        await query.answer("Access denied", show_alert=True)
        return

    # Navigation callbacks
    if data == "menu_home":
        await query.answer()
        return await show_home(query.message, uid, r, is_edit=True)

    if data == "nav_create":
        await query.answer()
        return await query.edit_text(
            "⚡ *SELECT VIP KEY DURATION:*",
            parse_mode="Markdown",
            reply_markup=create_duration_inline_keyboard(),
        )

    if data == "nav_keys_list":
        await query.answer()
        return await handle_list_keys(query.message, uid, r, is_edit=True)

    if data == "nav_hwid_list":
        await query.answer()
        return await handle_hwid_menu(query.message, uid, r, is_edit=True)

    if data == "nav_extend_list":
        await query.answer()
        return await handle_extend_menu(query.message, uid, r, is_edit=True)

    if data == "nav_delete_list":
        await query.answer()
        return await handle_delete_menu(query.message, uid, r, is_edit=True)

    if data == "nav_stats":
        await query.answer()
        return await handle_stats(query.message, uid, r, is_edit=True)

    if data == "nav_roles_panel":
        await query.answer()
        return await handle_roles_menu(query.message, uid, r, is_edit=True)

    # Key generation callback: gen_dur:value:unit:tier
    if data.startswith("gen_dur:"):
        _, v, u, t = data.split(":")
        return await execute_key_generation(update, context, int(v), u, t)

    # View single key
    if data.startswith("view_key:"):
        key = data.split(":", 1)[1]
        await query.answer()
        return await handle_view_single_key(query, key, uid, r)

    # Action: Toggle key enable/disable
    if data.startswith("act_toggle:"):
        key = data.split(":", 1)[1]
        row = get_key(key)
        if not row:
            return await query.answer("Key not found!", show_alert=True)
        if r == "reseller" and row["owner_id"] != uid:
            return await query.answer("You can only modify your own keys!", show_alert=True)
        new_state = 0 if row["active"] else 1
        toggle_key(key, new_state)
        audit(uid, r, "TOGGLE_KEY", key, f"active={new_state}")
        await query.answer(f"Key is now {'ACTIVATED 🟢' if new_state else 'DISABLED 🔴'}!")
        return await handle_view_single_key(query, key, uid, r)

    # Action: Reset HWID
    if data.startswith("act_hwid:"):
        key = data.split(":", 1)[1]
        row = get_key(key)
        if not row:
            return await query.answer("Key not found!", show_alert=True)
        if r == "reseller" and row["owner_id"] != uid:
            return await query.answer("You can only modify your own keys!", show_alert=True)
        reset_hwid(key)
        audit(uid, r, "RESET_HWID", key)
        await query.answer("✅ Device HWID reset successfully!", show_alert=True)
        return await handle_view_single_key(query, key, uid, r)

    # Action: Extend options
    if data.startswith("act_ext_select:"):
        key = data.split(":", 1)[1]
        await query.answer()
        return await show_duration_extension_options(query, key)

    # Action: Extend execute
    if data.startswith("act_ext:"):
        _, key, val = data.split(":")
        row = get_key(key)
        if not row:
            return await query.answer("Key not found!", show_alert=True)
        if r == "reseller" and row["owner_id"] != uid:
            return await query.answer("You can only modify your own keys!", show_alert=True)

        if val == "life":
            set_lifetime(key)
            audit(uid, r, "EXTEND_KEY_LIFE", key)
            await query.answer("👑 Key upgraded to Lifetime VIP!", show_alert=True)
        else:
            extend_key(key, int(val))
            audit(uid, r, "EXTEND_KEY_DAYS", key, f"days={val}")
            await query.answer(f"⏳ Duration extended by +{val} days!", show_alert=True)

        return await handle_view_single_key(query, key, uid, r)

    # Action: Delete confirm prompt
    if data.startswith("act_del_confirm:"):
        key = data.split(":", 1)[1]
        await query.answer()
        text = (
            f"⚠️ *ARE YOU SURE YOU WANT TO DELETE THIS KEY?*\n"
            f"🔑 *Key:* `{key}`\n\n"
            f"This will immediately invalidate the user's iOS app access."
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🗑️ Yes, Delete Key", callback_data=f"act_del_exec:{key}")],
            [InlineKeyboardButton("❌ Cancel", callback_data=f"view_key:{key}")],
        ])
        return await query.edit_text(text, parse_mode="Markdown", reply_markup=kb)

    # Action: Delete execute
    if data.startswith("act_del_exec:"):
        key = data.split(":", 1)[1]
        row = get_key(key)
        if not row:
            return await query.answer("Key not found!", show_alert=True)
        if r == "reseller" and row["owner_id"] != uid:
            return await query.answer("You can only delete your own keys!", show_alert=True)
        delete_key(key)
        audit(uid, r, "DELETE_KEY", key)
        await query.answer("🗑️ Key deleted successfully!", show_alert=True)
        return await handle_list_keys(query.message, uid, r, is_edit=True)

    # ================= USER ROLES CALLBACKS =================
    if data.startswith("role_list:"):
        target_role = data.split(":")[1]
        await query.answer()
        return await handle_user_list_by_role(query, target_role, r)

    if data.startswith("user_detail:"):
        target_id = int(data.split(":")[1])
        await query.answer()
        return await handle_single_user_detail(query, target_id, r)

    # Toggle user block / unblock
    if data.startswith("user_toggle_active:"):
        target_id = int(data.split(":")[1])
        u_row = get_user(target_id)
        if not u_row:
            return await query.answer("User not found!", show_alert=True)
        new_active = 0 if u_row["active"] else 1
        set_user_active(target_id, new_active)
        audit(uid, r, "TOGGLE_USER_ACTIVE", str(target_id), f"active={new_active}")
        state_msg = "UNBLOCKED 🟢" if new_active else "BLOCKED 🚫"
        await query.answer(f"User {target_id} is now {state_msg}!", show_alert=True)
        return await handle_single_user_detail(query, target_id, r)

    # Revoke all keys for a specific user
    if data.startswith("user_revoke_keys_confirm:"):
        target_id = int(data.split(":")[1])
        await query.answer()
        text = (
            f"⚠️ *REVOKE ALL LICENSES FOR USER `{target_id}`?*\n"
            f"This will permanently delete every key ever generated by this user!"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🗑️ Yes, Revoke All Keys", callback_data=f"user_revoke_keys_exec:{target_id}")],
            [InlineKeyboardButton("❌ Cancel", callback_data=f"user_detail:{target_id}")],
        ])
        return await query.edit_text(text, parse_mode="Markdown", reply_markup=kb)

    if data.startswith("user_revoke_keys_exec:"):
        target_id = int(data.split(":")[1])
        revoke_user_keys(target_id)
        audit(uid, r, "REVOKE_USER_KEYS", str(target_id))
        await query.answer(f"All keys for {target_id} have been revoked!", show_alert=True)
        return await handle_single_user_detail(query, target_id, r)

    # Revoke account entirely
    if data.startswith("user_revoke_account_confirm:"):
        target_id = int(data.split(":")[1])
        await query.answer()
        text = (
            f"⚠️ *PERMANENTLY DELETE ACCOUNT `{target_id}`?*\n"
            f"This will remove the user's role and delete their account from the system."
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🗑️ Yes, Delete Account", callback_data=f"user_revoke_account_exec:{target_id}")],
            [InlineKeyboardButton("❌ Cancel", callback_data=f"user_detail:{target_id}")],
        ])
        return await query.edit_text(text, parse_mode="Markdown", reply_markup=kb)

    if data.startswith("user_revoke_account_exec:"):
        target_id = int(data.split(":")[1])
        revoke_user(target_id)
        audit(uid, r, "REVOKE_USER_ACCOUNT", str(target_id))
        await query.answer(f"Account {target_id} has been revoked and removed!", show_alert=True)
        return await handle_roles_menu(query.message, uid, r, is_edit=True)

    # Bulk actions menu
    if data == "role_bulk_menu":
        await query.answer()
        return await handle_bulk_actions_menu(query, r)

    if data.startswith("bulk_exec:"):
        _, target_role, active_str = data.split(":")
        set_all_active_by_role(target_role, int(active_str))
        audit(uid, r, "BULK_ACTIVE_TOGGLE", target_role, f"active={active_str}")
        action_name = "UNBLOCKED 🟢" if active_str == "1" else "BLOCKED 🚫"
        await query.answer(f"All {target_role} accounts are now {action_name}!", show_alert=True)
        return await handle_bulk_actions_menu(query, r)

    if data == "role_purge_expired":
        if r != "owner":
            return await query.answer("Owner only!", show_alert=True)
        delete_all_expired()
        audit(uid, "owner", "DELETE_ALL_EXPIRED")
        await query.answer("🧹 All expired licenses have been purged!", show_alert=True)
        return await show_home(query.message, uid, r, is_edit=True)

    # Interactive prompts for adding seller, admin, or adjusting credits
    if data in ("role_add_seller", "role_add_admin", "role_set_credits") or data.startswith("user_credit_prompt:"):
        context.user_data["awaiting_action"] = data
        action_prompts = {
            "role_add_seller": "Send the Telegram User ID of the new Seller (e.g., 123456789):",
            "role_add_admin": "Send the Telegram User ID of the new Admin (e.g., 123456789):",
            "role_set_credits": "Send User ID and credits amount (e.g., 123456789 50):",
        }
        prompt_text = action_prompts.get(data, f"Send credit amount to add or deduct for ID `{data.split(':')[-1]}` (e.g. 50 or -10):")
        await query.answer()
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="nav_roles_panel")]])
        return await query.edit_text(f"📝 *{prompt_text}*", parse_mode="Markdown", reply_markup=kb)


# ==================== TEXT & BOTTOM BUTTON ROUTER ====================

async def handle_user_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Processes reply keyboard buttons or direct text input — zero slash commands required!"""
    uid = update.effective_user.id
    r = role(uid)
    if not r:
        return await update.message.reply_text("⛔ Access denied. Contact the Owner (@MYZO_PANEL) for access.")

    text = update.message.text.strip()

    # Check for pending role/user actions
    pending = context.user_data.pop("awaiting_action", None)
    if pending:
        if pending == "role_add_seller":
            if text.isdigit():
                target = int(text)
                db = conn()
                db.execute(
                    "INSERT INTO users(telegram_id,name,role,active,credits,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(telegram_id) DO UPDATE SET role='reseller',active=1",
                    (target, "", "reseller", 1, 10, now()),
                )
                db.commit(); db.close()
                audit(uid, r, "ADD_SELLER", str(target))
                return await update.message.reply_text(f"✅ *Seller Added Successfully!*\nUser ID: `{target}` (Initial Credits: 10)", parse_mode="Markdown", reply_markup=main_reply_keyboard(r))
            else:
                return await update.message.reply_text("❌ Invalid ID. Please send numeric Telegram ID only.", reply_markup=main_reply_keyboard(r))

        if pending == "role_add_admin":
            if text.isdigit() and r == "owner":
                target = int(text)
                db = conn()
                db.execute(
                    "INSERT INTO users(telegram_id,name,role,active,credits,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(telegram_id) DO UPDATE SET role='admin',active=1",
                    (target, "", "admin", 1, 0, now()),
                )
                db.commit(); db.close()
                audit(uid, "owner", "ADD_ADMIN", str(target))
                return await update.message.reply_text(f"👑 *Admin Added Successfully!*\nUser ID: `{target}`", parse_mode="Markdown", reply_markup=main_reply_keyboard(r))

        if pending == "role_set_credits":
            parts = text.split()
            if len(parts) >= 2 and parts[0].isdigit():
                target = int(parts[0])
                try:
                    amount = int(parts[1])
                    db = conn()
                    db.execute("UPDATE users SET credits=credits+? WHERE telegram_id=?", (amount, target))
                    db.execute("INSERT INTO credit_log(actor_id,target_id,amount,reason,created_at) VALUES(?,?,?,?,?)", (uid, target, amount, "admin adjustment", now()))
                    db.commit(); db.close()
                    audit(uid, r, "CREDIT_ADJUST", str(target), f"amount={amount}")
                    return await update.message.reply_text(f"💳 *Credits Updated for `{target}`*\nAdjustment: `{amount:+d}`", parse_mode="Markdown", reply_markup=main_reply_keyboard(r))
                except ValueError:
                    pass

        if pending.startswith("user_credit_prompt:"):
            target_id = int(pending.split(":")[1])
            try:
                amount = int(text)
                db = conn()
                db.execute("UPDATE users SET credits=credits+? WHERE telegram_id=?", (amount, target_id))
                db.execute("INSERT INTO credit_log(actor_id,target_id,amount,reason,created_at) VALUES(?,?,?,?,?)", (uid, target_id, amount, "admin adjustment", now()))
                db.commit(); db.close()
                audit(uid, r, "CREDIT_ADJUST", str(target_id), f"amount={amount}")
                return await update.message.reply_text(f"💳 *Credits Updated for `{target_id}`*\nAdjustment: `{amount:+d}`", parse_mode="Markdown", reply_markup=main_reply_keyboard(r))
            except ValueError:
                pass

    # Button: Create Key
    if "Create Key" in text or "Create" in text:
        return await handle_create_key_button(update.message, uid, r)

    # Button: Manage Keys / List
    if "Manage Keys" in text or "My Keys" in text or "Keys" in text:
        return await handle_list_keys(update.message, uid, r)

    # Button: Reset HWID
    if "HWID" in text:
        return await handle_hwid_menu(update.message, uid, r)

    # Button: Extend Key
    if "Extend" in text:
        return await handle_extend_menu(update.message, uid, r)

    # Button: Delete Key
    if "Delete" in text:
        return await handle_delete_menu(update.message, uid, r)

    # Button: Stats or Balance
    if "Stats" in text or "Balance" in text:
        return await handle_stats(update.message, uid, r)

    # Button: Roles / Sellers / Admins
    if "Panel" in text or "Roles" in text or "Sellers" in text or "Admin" in text:
        return await handle_roles_menu(update.message, uid, r)

    # Button: Purge Expired
    if "Purge" in text:
        if r == "owner":
            delete_all_expired()
            audit(uid, "owner", "DELETE_ALL_EXPIRED")
            return await update.message.reply_text("🧹 *All expired licenses purged successfully!*", parse_mode="Markdown", reply_markup=main_reply_keyboard(r))

    # Check if user sent a Key directly (e.g. pasted MYZO-VIP-...)
    if text.upper().startswith("MYZO-") or len(text) > 15:
        match = re.search(r"MYZO-[A-Za-z0-9]+-[A-Za-z0-9]+-[A-Za-z0-9]+", text.upper())
        search_key = match.group(0) if match else text.upper().strip()
        row = get_key(search_key)
        if row:
            st = "🟢 ACTIVE" if row["active"] else "🔴 DISABLED"
            hwid_text = f"📱 Locked (`{row['device_id']}`)" if row["device_id"] else "🔓 Unlocked"
            exp_text = row["expires_at"][:19] + " UTC" if row["expires_at"] else "♾️ Lifetime VIP"
            detail = (
                f"🔑 *LICENSE FOUND!*\n"
                f"• *Key:* `{search_key}`\n"
                f"• *Status:* {st}\n"
                f"• *Expires:* `{exp_text}`\n"
                f"• *HWID:* {hwid_text}\n\n"
                f"Tap any button below to manage:"
            )
            return await update.message.reply_text(
                detail,
                parse_mode="Markdown",
                reply_markup=key_detail_keyboard(search_key, row["active"], row["device_id"]),
            )

    # Default fallback: show home menu
    await show_home(update.message, uid, r)


# ==================== MAIN ====================

def main():
    if not BOT_TOKEN:
        raise SystemExit("Error: Set BOT_TOKEN in .env")

    init()
    print("🤖 FOUGO VIP Telegram Bot Starting (English Only • All Buttons)...")
    app = Application.builder().token(BOT_TOKEN).build()

    # Master Callback Query Handler (handles all inline buttons)
    app.add_handler(CallbackQueryHandler(master_callback_handler))

    # Fallback start command
    app.add_handler(CommandHandler("start", lambda u, c: show_home(u.message, u.effective_user.id, role(u.effective_user.id))))

    # Master text message handler for all bottom reply buttons and pasted keys
    app.add_handler(MessageHandler(filters.TEXT, handle_user_text_message))

    print("✅ Bot is online! Pure English button-driven interface active.")
    app.run_polling()


if __name__ == "__main__":
    main()
