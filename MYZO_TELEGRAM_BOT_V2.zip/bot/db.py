import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from bot.config import DB_PATH


def now():
    return datetime.now(timezone.utc).isoformat()


def conn():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init():
    c = conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      telegram_id INTEGER PRIMARY KEY,
      name TEXT,
      role TEXT NOT NULL DEFAULT 'reseller',
      active INTEGER NOT NULL DEFAULT 1,
      credits INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS instances(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS licenses(
      key TEXT PRIMARY KEY,
      owner_id INTEGER NOT NULL,
      duration_value INTEGER NOT NULL,
      duration_unit TEXT NOT NULL,
      created_at TEXT NOT NULL,
      expires_at TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      device_id TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS license_instances(
      license_key TEXT NOT NULL,
      instance_id INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      PRIMARY KEY (license_key, instance_id),
      FOREIGN KEY (license_key) REFERENCES licenses(key) ON DELETE CASCADE,
      FOREIGN KEY (instance_id) REFERENCES instances(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS audit(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_id INTEGER NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      target TEXT DEFAULT '',
      details TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS credit_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_id INTEGER NOT NULL,
      target_id INTEGER NOT NULL,
      amount INTEGER NOT NULL,
      reason TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );
    """)

    # Backward-compatible migration for the old licenses table.
    cols = {r[1] for r in c.execute("PRAGMA table_info(licenses)").fetchall()}
    if "duration_value" not in cols:
        c.execute("ALTER TABLE licenses ADD COLUMN duration_value INTEGER NOT NULL DEFAULT 0")
    if "duration_unit" not in cols:
        c.execute("ALTER TABLE licenses ADD COLUMN duration_unit TEXT NOT NULL DEFAULT 'd'")
    if "expires_at" not in cols:
        c.execute("ALTER TABLE licenses ADD COLUMN expires_at TEXT")

    # Migrate old 'days' values into duration_value/duration_unit where possible.
    if "days" in cols:
        c.execute("UPDATE licenses SET duration_value=days, duration_unit='d' WHERE duration_value=0 AND days>0")

    c.commit(); c.close()


def audit(actor, role, action, target="", details=""):
    c = conn()
    c.execute(
        "INSERT INTO audit(actor_id,actor_role,action,target,details,created_at) VALUES(?,?,?,?,?,?)",
        (actor, role, action, target, details, now()),
    )
    c.commit(); c.close()


def get_key(key: str):
    c = conn()
    row = c.execute("SELECT * FROM licenses WHERE key=?", (key.strip().upper(),)).fetchone()
    c.close()
    return row


def toggle_key(key: str, active: int):
    c = conn()
    c.execute("UPDATE licenses SET active=? WHERE key=?", (active, key.strip().upper()))
    c.commit(); c.close()


def reset_hwid(key: str):
    c = conn()
    c.execute("UPDATE licenses SET device_id='' WHERE key=?", (key.strip().upper()))
    c.commit(); c.close()


def extend_key(key: str, days: int = 0, hours: int = 0):
    c = conn()
    row = c.execute("SELECT expires_at FROM licenses WHERE key=?", (key.strip().upper(),)).fetchone()
    if not row:
        c.close(); return None
    from datetime import timedelta
    current_exp = row["expires_at"]
    base_time = datetime.fromisoformat(current_exp) if current_exp else datetime.now(timezone.utc)
    if base_time < datetime.now(timezone.utc):
        base_time = datetime.now(timezone.utc)
    new_exp = base_time + timedelta(days=days, hours=hours)
    c.execute("UPDATE licenses SET expires_at=?, active=1 WHERE key=?", (new_exp.isoformat(), key.strip().upper()))
    c.commit(); c.close()
    return new_exp.isoformat()


def set_lifetime(key: str):
    c = conn()
    c.execute("UPDATE licenses SET expires_at=NULL, duration_unit='life', duration_value=0, active=1 WHERE key=?", (key.strip().upper(),))
    c.commit(); c.close()


def delete_key(key: str):
    c = conn()
    c.execute("DELETE FROM licenses WHERE key=?", (key.strip().upper(),))
    c.execute("DELETE FROM license_instances WHERE license_key=?", (key.strip().upper(),))
    c.commit(); c.close()


def delete_all_expired():
    c = conn()
    now_iso = now()
    c.execute("DELETE FROM licenses WHERE expires_at IS NOT NULL AND expires_at < ?", (now_iso,))
    c.commit(); c.close()


def get_user(telegram_id: int):
    c = conn()
    row = c.execute("SELECT * FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
    c.close()
    return row


def list_users(role_filter: str | None = None):
    c = conn()
    if role_filter:
        rows = c.execute("SELECT * FROM users WHERE role=? ORDER BY telegram_id", (role_filter,)).fetchall()
    else:
        rows = c.execute("SELECT * FROM users ORDER BY role, telegram_id").fetchall()
    c.close()
    return rows


def set_user_active(telegram_id: int, active: int):
    c = conn()
    c.execute("UPDATE users SET active=? WHERE telegram_id=?", (active, telegram_id))
    c.commit(); c.close()


def revoke_user(telegram_id: int):
    """Permanently delete user record and demote."""
    c = conn()
    c.execute("DELETE FROM users WHERE telegram_id=?", (telegram_id,))
    c.commit(); c.close()


def revoke_user_keys(telegram_id: int):
    """Permanently delete/revoke all keys created by a specific user/seller."""
    c = conn()
    c.execute("DELETE FROM licenses WHERE owner_id=?", (telegram_id,))
    c.commit(); c.close()


def set_all_active_by_role(role_name: str, active: int):
    """Bulk block or unblock all users of a specific role."""
    c = conn()
    c.execute("UPDATE users SET active=? WHERE role=?", (active, role_name))
    c.commit(); c.close()


